create
    definer = root@localhost procedure search_by(IN input varchar(120))
begin
	select * from product
    where product.product_name like concat("%",input,"%") or product.description like concat("%",input,"%");
end;

