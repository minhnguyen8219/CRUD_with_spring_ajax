create
    definer = root@localhost procedure getIdMax()
begin
	select max(order_id) as order_id
    from orders;
end;

